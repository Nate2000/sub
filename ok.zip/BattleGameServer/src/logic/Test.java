package logic;

public class Test {
	
	public static void main(String[] args) {
		new Test();
	}
	
	public Test() {
		long before = System.currentTimeMillis();
		
		try {
			Thread.sleep(0, 1);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		long after = System.currentTimeMillis();
		long dif = after - before;
		System.out.println(dif);
	}

}

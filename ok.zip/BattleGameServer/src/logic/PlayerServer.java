package logic;

import java.util.ArrayList;

public class PlayerServer {

	private String name;
	
	private double x = 0;
	private double y = 0;
	
	private ArrayList<BulletServer> bullets = new ArrayList<BulletServer>();
	
	public PlayerServer(String name, int x, int y) {
		this.x = x;
		this.y = y;
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public ArrayList<BulletServer> getBullets() {
		return bullets;
	}

	public void setBullets(ArrayList<BulletServer> bullets) {
		this.bullets = bullets;
	}

}
package logic;

import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Map.Entry;
import java.util.Timer;
import java.util.TimerTask;

public class Server {

	private ServerSocket listenPositionRequestsSocketP1;
	private ServerSocket listenBulletRequestsSocketP1;

	private Timer listenPositionRequestsTimerP1;
	private Timer listenBulletRequestsTimerP1;

	private ServerSocket listenPositionRequestsSocketP2;
	private ServerSocket listenBulletRequestsSocketP2;

	private Timer listenPositionRequestsTimerP2;
	private Timer listenBulletRequestsTimerP2;

	private HashMap<String, PlayerServer> players = new HashMap<String, PlayerServer>();

	private String serverIp = "192.168.94.1";

	private int listenPositionPortP1 = 50072;
	private int listenBulletPortP1 = 50073;

	private int listenPositionPortP2 = 50074;
	private int listenBulletPortP2 = 50075;

	public static void main(String[] args) {
		new Server();
	}

	public Server() {
		listenPositionRequestP1();
		listenBulletRequestsP1();
		listenPositionRequestP2();
		listenBulletRequestsP2();
	}

	@SuppressWarnings({ "unused" })
	public void listenPositionRequestP1() {
		listenPositionRequestsTimerP1 = new Timer();
		TimerTask task = new TimerTask() {
			@Override
			public void run() {
				try {
					String connectionString = "listening for position requests: " + serverIp + "@"
							+ listenPositionPortP1;
					System.out.println(connectionString);

					listenPositionRequestsSocketP1 = new ServerSocket();
					listenPositionRequestsSocketP1.setReceiveBufferSize(255);
					listenPositionRequestsSocketP1.bind(new InetSocketAddress(serverIp, listenPositionPortP1));
					Socket connectionSocket = listenPositionRequestsSocketP1.accept();

					// read action
					InputStream action = connectionSocket.getInputStream();
					byte[] bytesAction = new byte[255];
					int bytesActionRead = action.read(bytesAction, 0, bytesAction.length);

					String[] actionArray = new String(bytesAction).split("/");

					if (players.get(actionArray[0]) != null) {
						if ("ded".equals(actionArray[1])) {
							players.remove(actionArray[0]);
						} else {
							players.get(actionArray[0]).setX(Integer.parseInt(actionArray[1]));
							players.get(actionArray[0]).setY(Integer.parseInt(actionArray[2]));
						}
					} else {
						players.put(actionArray[0], new PlayerServer(actionArray[0], Integer.parseInt(actionArray[1]),
								Integer.parseInt(actionArray[2])));
					}

//					if (players.size() >= 2) {
						String response = "";

						Iterator<Entry<String, PlayerServer>> it = players.entrySet().iterator();
						while (it.hasNext()) {
							Map.Entry<String, PlayerServer> pair = (Map.Entry<String, PlayerServer>) it.next();
							if (!pair.getValue().getName().equals(actionArray[0])) {
								response += pair.getValue().getName() + "/" + (int) pair.getValue().getX() + "/"
										+ (int) pair.getValue().getY() + "/";
							}
						}

						connectionSocket.getOutputStream().write(response.getBytes());
//					}

					listenPositionRequestsSocketP1.close();
					connectionSocket.close();
				} catch (Exception e) {
					e.printStackTrace();
					System.err.println("listen to position requests failed");
				}
			}
		};
		listenPositionRequestsTimerP1.schedule(task, 0, 1);
	}

	@SuppressWarnings({ "unused" })
	public void listenBulletRequestsP1() {
		listenBulletRequestsTimerP1 = new Timer();
		TimerTask task = new TimerTask() {
			@Override
			public void run() {
				try {
					String connectionString = "listening for bullet requests: " + serverIp + "@" + listenBulletPortP1;
					System.out.println(connectionString);

					listenBulletRequestsSocketP1 = new ServerSocket();
					listenBulletRequestsSocketP1.setReceiveBufferSize(255);
					listenBulletRequestsSocketP1.bind(new InetSocketAddress(serverIp, listenBulletPortP1));
					Socket connectionSocket = listenBulletRequestsSocketP1.accept();

					// read action
					InputStream action = connectionSocket.getInputStream();
					byte[] bytesAction = new byte[255];
					int bytesActionRead = action.read(bytesAction, 0, bytesAction.length);

					String[] actionArray = new String(bytesAction).split("/");

					if (players.get(actionArray[0]) != null) {
						if (actionArray.length > 2) {
							players.get(actionArray[0]).getBullets()
									.add(new BulletServer(Integer.parseInt(actionArray[1]),
											Integer.parseInt(actionArray[2]), Integer.parseInt(actionArray[3])));
						}

						String response = "";
						boolean responseAvailable = false;
						if (players.size() >= 2) {

							Iterator<Entry<String, PlayerServer>> it = players.entrySet().iterator();
							while (it.hasNext()) {
								Map.Entry<String, PlayerServer> pair = (Map.Entry<String, PlayerServer>) it.next();
								if (!pair.getValue().getName().equals(actionArray[0])) {
									ArrayList<BulletServer> deleteBullets = new ArrayList<BulletServer>();
									for (BulletServer b : pair.getValue().getBullets()) {
										responseAvailable = true;
										response += pair.getValue().getName() + "/" + (int) b.getX() + "/"
												+ (int) b.getY() + "/" + (int) b.getPointer() + "/";
										deleteBullets.add(b);
									}
									pair.getValue().getBullets().removeAll(deleteBullets);
									pair.getValue().getBullets().removeIf(Objects::isNull);
								}
							}

						}
						if (!responseAvailable) {
							response = "nobullet/";
						}
						connectionSocket.getOutputStream().write(response.getBytes());

					}

					listenBulletRequestsSocketP1.close();
					connectionSocket.close();
				} catch (Exception e) {
					e.printStackTrace();
					System.err.println("listen to bullet requests failed");
				}
			}
		};
		listenBulletRequestsTimerP1.schedule(task, 0, 1);

	}

	@SuppressWarnings({ "unused" })
	public void listenPositionRequestP2() {
		listenPositionRequestsTimerP2 = new Timer();
		TimerTask task = new TimerTask() {
			@Override
			public void run() {
				try {
					String connectionString = "listening for position requests: " + serverIp + "@"
							+ listenPositionPortP2;
					System.out.println(connectionString);

					listenPositionRequestsSocketP2 = new ServerSocket();
					listenPositionRequestsSocketP2.setReceiveBufferSize(255);
					listenPositionRequestsSocketP2.bind(new InetSocketAddress(serverIp, listenPositionPortP2));
					Socket connectionSocket = listenPositionRequestsSocketP2.accept();

					// read action
					InputStream action = connectionSocket.getInputStream();
					byte[] bytesAction = new byte[255];
					int bytesActionRead = action.read(bytesAction, 0, bytesAction.length);

					String[] actionArray = new String(bytesAction).split("/");

					if (players.get(actionArray[0]) != null) {
						players.get(actionArray[0]).setX(Integer.parseInt(actionArray[1]));
						players.get(actionArray[0]).setY(Integer.parseInt(actionArray[2]));
					} else {
						players.put(actionArray[0], new PlayerServer(actionArray[0], Integer.parseInt(actionArray[1]),
								Integer.parseInt(actionArray[2])));
					}

//					if (players.size() >= 2) {
						String response = "";

						Iterator<Entry<String, PlayerServer>> it = players.entrySet().iterator();
						while (it.hasNext()) {
							Map.Entry<String, PlayerServer> pair = (Map.Entry<String, PlayerServer>) it.next();
							if (!pair.getValue().getName().equals(actionArray[0])) {
								response += pair.getValue().getName() + "/" + (int) pair.getValue().getX() + "/"
										+ (int) pair.getValue().getY() + "/";
							}
						}

						connectionSocket.getOutputStream().write(response.getBytes());
//					}

					listenPositionRequestsSocketP2.close();
					connectionSocket.close();
				} catch (Exception e) {
					e.printStackTrace();
					System.err.println("listen to position requests failed");
				}
			}
		};
		listenPositionRequestsTimerP2.schedule(task, 0, 1);
	}

	@SuppressWarnings({ "unused" })
	public void listenBulletRequestsP2() {
		listenBulletRequestsTimerP2 = new Timer();
		TimerTask task = new TimerTask() {
			@Override
			public void run() {
				try {
					String connectionString = "listening for bullet requests: " + serverIp + "@" + listenBulletPortP2;
					System.out.println(connectionString);

					listenBulletRequestsSocketP2 = new ServerSocket();
					listenBulletRequestsSocketP2.setReceiveBufferSize(255);
					listenBulletRequestsSocketP2.bind(new InetSocketAddress(serverIp, listenBulletPortP2));
					Socket connectionSocket = listenBulletRequestsSocketP2.accept();

					// read action
					InputStream action = connectionSocket.getInputStream();
					byte[] bytesAction = new byte[255];
					int bytesActionRead = action.read(bytesAction, 0, bytesAction.length);

					String[] actionArray = new String(bytesAction).split("/");

					if (players.get(actionArray[0]) != null) {
						if (actionArray.length > 2) {
							players.get(actionArray[0]).getBullets()
									.add(new BulletServer(Integer.parseInt(actionArray[1]),
											Integer.parseInt(actionArray[2]), Integer.parseInt(actionArray[3])));
						}

						String response = "";
						boolean responseAvailable = false;
						if (players.size() >= 2) {

							Iterator<Entry<String, PlayerServer>> it = players.entrySet().iterator();
							while (it.hasNext()) {
								Map.Entry<String, PlayerServer> pair = (Map.Entry<String, PlayerServer>) it.next();
								if (!pair.getValue().getName().equals(actionArray[0])) {
									ArrayList<BulletServer> deleteBullets = new ArrayList<BulletServer>();
									for (BulletServer b : pair.getValue().getBullets()) {
										responseAvailable = true;
										response += pair.getValue().getName() + "/" + (int) b.getX() + "/"
												+ (int) b.getY() + "/" + (int) b.getPointer() + "/";
										deleteBullets.add(b);
									}
									pair.getValue().getBullets().removeAll(deleteBullets);
									pair.getValue().getBullets().removeIf(Objects::isNull);
								}
							}

						}
						if (!responseAvailable) {
							response = "nobullet/";
						}
						connectionSocket.getOutputStream().write(response.getBytes());
					}

					listenBulletRequestsSocketP2.close();
					connectionSocket.close();
				} catch (Exception e) {
					e.printStackTrace();
					System.err.println("listen to bullet requests failed");
				}
			}
		};
		listenBulletRequestsTimerP2.schedule(task, 0, 1);
	}
}

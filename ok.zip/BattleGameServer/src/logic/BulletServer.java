package logic;

public class BulletServer {

	private double x;
	private double y;

	private int pointer;

	public BulletServer(double x, double y, int pointer) {
		this.x = x;
		this.y = y;
		this.pointer = pointer;
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public int getPointer() {
		return pointer;
	}

	public void setPointer(int pointer) {
		this.pointer = pointer;
	}

}

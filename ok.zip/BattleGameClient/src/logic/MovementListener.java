package logic;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class MovementListener implements KeyListener {

	private Player player;

	public MovementListener(Player player) {
		this.player = player;
	}

	@Override
	public void keyPressed(KeyEvent key) {
		switch (KeyEvent.getKeyText(key.getKeyCode())) {
			case "D":
				player.setForward(true);
				break;
			case "W":
				player.setLeft(true);
				break;
			case "A":
				player.setBackwards(true);
				break;
			case "S":
				player.setRight(true);
				break;
			case "Left":
			case "Links":
				player.turnLeft();
				player.shoot();
				break;
			case "Right":
			case "Rechts":
				player.turnRight();
				player.shoot();
				break;
			case "Up":
			case "Oben":
				player.turnUp();
				player.shoot();
				break;
			case "Unten":
			case "Down":
				player.turnDown();
				player.shoot();
				break;
		}
	}

	@Override
	public void keyReleased(KeyEvent key) {
		switch (KeyEvent.getKeyText(key.getKeyCode())) {
			case "D":
				player.setForward(false);
				break;
			case "W":
				player.setLeft(false);
				break;
			case "A":
				player.setBackwards(false);
				break;
			case "S":
				player.setRight(false);
				break;
		}
	}

	@Override
	public void keyTyped(KeyEvent key) {
	}

}
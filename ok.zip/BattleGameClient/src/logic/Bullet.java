package logic;

public class Bullet {

	private String playerName;
	
	private double x;
	private double y;

	private int pointer;

	private double SPEED = 1;

	public Bullet(String playerName, int xSpawn, int ySpawn, int _pointer, double _SPEED) {
		this(playerName, xSpawn, ySpawn, _pointer);
		SPEED = _SPEED;	
	}
	
	public Bullet(String playerName, int xSpawn, int ySpawn, int _pointer) {
		setPlayerName(playerName);
		pointer = _pointer;

		switch (pointer) {
		case 1:
			y = ySpawn;
			x = xSpawn + 12;
			break;
		case 2:
			x = xSpawn;
			y = ySpawn + 12;
			break;
		case 3:
			y = ySpawn;
			x = xSpawn - 12;
			break;
		case 4:
			x = xSpawn;
			y = ySpawn - 12;
			break;
		}
	}

	public double getX() {
		switch (pointer) {
		case 1:
			setX(x + SPEED);
			break;
		case 3:
			setX(x - SPEED);
			break;
		}
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		switch (pointer) {
		case 2:
			setY(y + SPEED);
			break;
		case 4:
			setY(y - SPEED);
			break;
		}
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public int getPointer() {
		return pointer;
	}

	public void setPointer(int pointer) {
		this.pointer = pointer;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
}

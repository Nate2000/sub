package logic;

import java.io.InputStream;
import java.net.Socket;

import gui.GamePanel;

public class Client {

	private GamePanel gamePanel;

	private String serverIP = "192.168.94.1";

	private int listenPositionPort = 50074;
	private int listenBulletPort = 50075;

	private Socket sendPositionRequestsSocket;
	private Socket sendBulletRequestsSocket;

	public Client(GamePanel gamePanel) {
		this.gamePanel = gamePanel;
	}

	@SuppressWarnings("unused")
	public void sendPlayerRequest(Player player) {
		try {
			sendPositionRequestsSocket = new Socket(serverIP, listenPositionPort);
			sendPositionRequestsSocket.setKeepAlive(true);
			sendPositionRequestsSocket.setSendBufferSize(255);

			String send = "";
			if (player != null) {
				if (player.isDed()) {
					send += player.getName() + "/ded/";
				} else {
					send += player.getName() + "/" + (int) player.getX() + "/" + (int) player.getY() + "/";
				}
			}

			sendPositionRequestsSocket.getOutputStream().write((send).getBytes());

			InputStream playerStream = sendPositionRequestsSocket.getInputStream();
			byte[] bytesPlayer = new byte[255];
			int bytesPlayerRead = playerStream.read(bytesPlayer, 0, bytesPlayer.length);

			String[] actionArray = new String(bytesPlayer).split("/");

			if (actionArray.length > 2) {
				boolean found = false;
				for (Player p : gamePanel.getPlayers()) {
					if (p.getName().equals(actionArray[0])) {
						found = true;
						p.setX(Integer.parseInt(actionArray[1]));
						p.setY(Integer.parseInt(actionArray[2]));
					}
				}
				if (!found) {
					gamePanel.getPlayers().add(new Player(actionArray[0], Integer.parseInt(actionArray[1]),
							Integer.parseInt(actionArray[2]), true));
				}
			}

			sendPositionRequestsSocket.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("request command from the server failed");
		}
	}

	@SuppressWarnings("unused")
	public void sendBulletRequest(Player player) {
		try {
			sendBulletRequestsSocket = new Socket(serverIP, listenBulletPort);
			sendBulletRequestsSocket.setKeepAlive(true);
			sendBulletRequestsSocket.setSendBufferSize(255);

			String send = gamePanel.getPlayer().getName() + "/";
			Bullet bullet = null;
			if (player != null) {
				bullet = player.getScheduledBullet();
			}
			if (bullet != null) {
				send += (int) bullet.getX() + "/" + (int) bullet.getY() + "/" + bullet.getPointer() + "/";
			}

			sendBulletRequestsSocket.getOutputStream().write((send).getBytes());

			InputStream bulletStream = sendBulletRequestsSocket.getInputStream();
			byte[] bytesBullet = new byte[255];
			int bytesBulletRead = bulletStream.read(bytesBullet, 0, bytesBullet.length);

			String[] actionArray = new String(bytesBullet).split("/");

			if (actionArray.length > 2) {
				for (Player p : gamePanel.getPlayers()) {
					if (p.getName().equals(actionArray[0])) {
						p.getBullets().add(new Bullet(actionArray[0], Integer.parseInt(actionArray[1]),
								Integer.parseInt(actionArray[2]), Integer.parseInt(actionArray[3])));
					}
				}
			}

			sendBulletRequestsSocket.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("request bullets from the server failed");
		}
	}

}
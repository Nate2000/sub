package logic;

import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

public class Player {

	private double x = 0;
	private double y = 0;
	
	private String name;

	private int pointer = 1;
	
	private boolean ded = false;

	private ArrayList<Bullet> bullets = new ArrayList<Bullet>();

	private boolean forward = false;
	private boolean backwards = false;
	private boolean left = false;
	private boolean right = false;

	private long lastShot = 0l;
	
	private Bullet scheduledBullet;

	private double SPEED = 1;

	private double BULLET_SPEED = 1;

	private boolean isMultiplayer = false;

	private Image characterImage;

	private boolean enemy;

	public Player(String name, int x, int y, boolean enemy) {
		setName(name);
		setEnemy(enemy);
		if (isEnemy()) {
			loadCharacterImage("res\\enemy.png");
		} else {
			loadCharacterImage("res\\player.png");
		}
		getRandomSpawnPoint();
		 this.x = x;
		 this.y = y;
	}

	private void getRandomSpawnPoint() {
		int x = 0;
		while (x < 200 || x > 800) {
			x = 200 + (int) (Math.random() * 800);
		}
		int y = 0;
		while (y < 100 || y > 500) {
			y = 100 + (int) (Math.random() * 500);
		}
		setX(x);
		setY(y);
	}

	public void move() {
		if (forward) {
			moveForward();
		}
		if (backwards) {
			moveBackwards();
		}
		if (left) {
			moveLeft();
		}
		if (right) {
			moveRight();
		}
	}

	public void moveForward() {
		if (getX() + SPEED < 890) {
			setX(getX() + SPEED);
		}
	}

	public void moveBackwards() {
		if (getX() - SPEED > 0) {
			setX(getX() - SPEED);
		}
	}

	public void moveLeft() {
		if (getY() - SPEED > 0) {
			setY(getY() - SPEED);
		}
	}

	public void moveRight() {
		if (getY() + SPEED < 590) {
			setY(getY() + SPEED);
		}
	}

	public void turnLeft() {
		pointer = 3;
	}

	public void turnRight() {
		pointer = 1;
	}

	public void turnUp() {
		pointer = 4;
	}

	public void turnDown() {
		pointer = 2;
	}

	public void shoot() {
		long dif = System.currentTimeMillis() - lastShot;
		if (dif > 250 || lastShot == 0) {
			Bullet b = new Bullet(name, (int) getX(), (int) getY(), getPointer(), BULLET_SPEED);
			setScheduledBullet(b);
			bullets.add(b);
			lastShot = System.currentTimeMillis();
		}
	}

	public void loadCharacterImage(String path) {
		try {
			setCharacterImage(ImageIO.read(new File(path)));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public int getPointer() {
		return pointer;
	}

	public void setPointer(int pointer) {
		this.pointer = pointer;
	}

	public ArrayList<Bullet> getBullets() {
		return bullets;
	}

	public void setBullets(ArrayList<Bullet> bullets) {
		this.bullets = bullets;
	}

	public boolean isForward() {
		return forward;
	}

	public void setForward(boolean forward) {
		this.forward = forward;
	}

	public boolean isBackwards() {
		return backwards;
	}

	public void setBackwards(boolean backwards) {
		this.backwards = backwards;
	}

	public boolean isLeft() {
		return left;
	}

	public void setLeft(boolean left) {
		this.left = left;
	}

	public boolean isRight() {
		return right;
	}

	public void setRight(boolean right) {
		this.right = right;
	}

	public Image getCharacterImage() {
		return characterImage;
	}

	public void setCharacterImage(Image characterImage) {
		this.characterImage = characterImage;
	}

	public boolean isEnemy() {
		return enemy;
	}

	public void setEnemy(boolean enemy) {
		this.enemy = enemy;
	}

	public double getBULLET_SPEED() {
		return BULLET_SPEED;
	}

	public void setBULLET_SPEED(double bULLET_SPEED) {
		BULLET_SPEED = bULLET_SPEED;
	}

	public boolean isMultiplayer() {
		return isMultiplayer;
	}

	public void setMultiplayer(boolean isMultiplayer) {
		this.isMultiplayer = isMultiplayer;
	}

	public double getSPEED() {
		return SPEED;
	}

	public void setSPEED(double sPEED) {
		SPEED = sPEED;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Bullet getScheduledBullet() {
		Bullet sb = scheduledBullet;
		setScheduledBullet(null);
		return sb;
	}

	public void setScheduledBullet(Bullet scheduledBullet) {
		this.scheduledBullet = scheduledBullet;
	}

	public boolean isDed() {
		return ded;
	}

	public void setDed(boolean ded) {
		this.ded = ded;
	}
}

package gui;

public class Starter {

	public static void main(String[] args) {
		new GameFrame("lol");
	}
	
}

package gui;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Objects;

import javax.swing.JPanel;

import logic.Bullet;
import logic.Client;
import logic.MovementListener;
import logic.Player;

public class GamePanel extends JPanel {

	private static final long serialVersionUID = -7211278713951002269L;

	private Player player;

	private ArrayList<Player> players = new ArrayList<Player>();

	private Color friendlyBulletColor = new Color(0, 162, 232);
	private Color enemyBulletColor = new Color(240, 66, 74);

	private Client client;

	private int updatePosition;
	private int updateBullet;

	// private BufferedImage background;

	public GamePanel(String name) {
		setLayout(null);
		setSize(900, 600);

		client = new Client(this);

		player = new Player(name, 0, 200, false);
		players.add(player);

		addKeyListener(new MovementListener(player));

		setBackground(Color.black);

		// readImage();

		setFocusable(true);
		setOpaque(true);
		setVisible(true);
	}

	// private void readImage() {
	// try {
	// background = ImageIO.read(new File(Variables.BACKGROUND));
	// } catch (Exception e) {
	// }
	// }

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);

		if (updatePosition == 5) {
			client.sendPlayerRequest(player);
			updatePosition = 0;
		} else {
			updatePosition++;
		}

		if (updateBullet == 12) {
			client.sendBulletRequest(player);
			updateBullet = 0;
		} else {
			updateBullet++;
		}

		// draw Background
		// g.drawImage(background, 0, 0, 900, 600, this);

		ArrayList<Player> deletePlayers = new ArrayList<Player>();
		for (Player p : players) {
			p.move();
			g.drawImage(p.getCharacterImage(), (int) p.getX(), (int) p.getY(), 24, 60, null);

			if (p.isEnemy()) {
				g.setColor(enemyBulletColor);
			} else {
				g.setColor(friendlyBulletColor);
			}

			ArrayList<Bullet> deleteBullets = new ArrayList<Bullet>();
			for (Bullet b : p.getBullets()) {
				// Check if Bullet is out of map
				if (b.getX() > 900 || b.getX() < 0 || b.getY() > 600 || b.getY() < 0) {
					deleteBullets.add(b);
				}

				Rectangle r = new Rectangle((int) b.getX(), (int) b.getY(), 8, 8);
				g.fillRoundRect((int) r.getX(), (int) r.getY(), (int) r.getHeight(), (int) r.getWidth(), 8, 8);

				// Check if Bullet hit enemy
				for (Player pp : players) {
					if (r.intersects(new Rectangle((int) pp.getX(), (int) pp.getY(), 10, 10))) {
						deletePlayers.add(pp);
						deleteBullets.add(b);
					}
				}
			}
			// Remove Bullets
			p.getBullets().removeAll(deleteBullets);
			p.getBullets().removeIf(Objects::isNull);
		}
		
		boolean you = false;
		// Remove Players
		for (Player ppp : deletePlayers) {
			ArrayList<Bullet> deleteBullets = new ArrayList<Bullet>();
			for (Bullet b : ppp.getBullets()) {
				deleteBullets.add(b);
			}
			ppp.getBullets().removeAll(deleteBullets);
			ppp.getBullets().removeIf(Objects::isNull);
			
			if (ppp.getName().equals(player.getName())) {
				player.setDed(true);
				client.sendPlayerRequest(player);
				you = true;
			}
			
			players.remove(ppp);
		}
		players.removeIf(Objects::isNull);
		
		if(you) {
			player = null;
		}


		// request focus
		requestFocusInWindow();

		// Loop
		revalidate();
		repaint();
	}

	public Player getPlayer() {
		return player;
	}

	public void setPlayer(Player player) {
		this.player = player;
	}

	public ArrayList<Player> getPlayers() {
		return this.players;
	}

	public void setPlayers(ArrayList<Player> players) {
		this.players = players;
	}
}

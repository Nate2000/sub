package gui;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

import util.FrameDragListener;
import util.Variables;

public class GameFrame extends JFrame {

	private static final long serialVersionUID = -4296269887521887723L;

	public GameFrame(String name) {
		// Removes Border and adds a FrameDragListener to the JFrame
		setUndecorated(true);
		FrameDragListener frameDragListener = new FrameDragListener(this);
		addMouseListener(frameDragListener);
		addMouseMotionListener(frameDragListener);

		// adds the exit button
		JButton exitButton = new JButton();
		exitButton.setBorder(null);
		exitButton.setIcon(new ImageIcon(Variables.CLOSE));
		exitButton.setBounds(882, 0, 18, 18);
		exitButton.setBackground(Color.GRAY);
		exitButton.setActionCommand("exit");
		exitButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		add(exitButton);

		setTitle(Variables.NAME);
		setSize(900, 600);
		setResizable(false);
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		setLocationRelativeTo(null);

		GamePanel gamePanel = new GamePanel(name);
		gamePanel.setBounds(900, 600, 0, 0);
		add(gamePanel);

		setVisible(true);
	}
}

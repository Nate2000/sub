package util;

public class Variables {

	public Variables(){
	}
		
	public static final String NAME = "BattleGame";
	public static final String VERSION = "v1";
	public static final String BACKGROUND = "res\\background.png";
	public static final String CLOSE = "res\\close.png";
	public static final String EXECUTE = "res\\execute.png";
	public static final String REFRESH = "res\\refresh.png";
	public static final String TERMINATE = "res\\terminate.png";
	
}
